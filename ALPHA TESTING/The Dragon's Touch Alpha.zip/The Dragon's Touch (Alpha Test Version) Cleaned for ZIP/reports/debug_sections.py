"""Debug/stress-test section builders.

These helpers format structured checkpoint summaries into separate debug files.
They intentionally do not perform analysis; they only render already-built data.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app_io.output_writer import get_unique_output_path, write_text_file
from analysis.deck_building_philosophies import render_philosophy_diagnostics_section
from legality.companion_rules import (
    COMPANION_CARD_NAMES,
    companion_is_banned_as_companion,
    get_companion_banned_note,
    get_companion_replacement_filter_note,
    get_companion_restriction_summary,
)


def _possible_companion_names_from_reference(context: dict[str, Any]) -> list[str]:
    parsed = context["parsed_deck"]
    command_zone = context.get("command_zone")
    known_companions = {str(name).lower() for name in getattr(command_zone, "companion_names", []) or []}
    candidates: list[str] = []
    for name in getattr(parsed, "reference_cards", []) or []:
        clean_name = str(name).strip()
        if clean_name in COMPANION_CARD_NAMES and clean_name.lower() not in known_companions:
            if clean_name not in candidates:
                candidates.append(clean_name)
    return candidates


@dataclass(slots=True)
class DebugSectionPaths:
    legality: Path
    strategy: Path
    bracket: Path
    cut_pressure: Path
    replacement_prompt: Path
    diagnostics: Path


def _bullet_list(values: list[str], empty: str = "None") -> list[str]:
    if not values:
        return [f"- {empty}"]
    return [f"- {value}" for value in values]


def _format_qa_ratio(numerator: int | float, denominator: int | float) -> str:
    """Format a small QA ratio without adding runtime dependencies."""
    try:
        n = float(numerator or 0)
        d = float(denominator or 0)
    except (TypeError, ValueError):
        return "not available"
    if d <= 0:
        return "not applicable"
    return f"{n / d:.2%}"


def _qa_counter_sanity(philosophy_context: dict[str, Any]) -> str:
    stats = philosophy_context.get("cut_bias_runtime_stats") or {}
    evaluated = int(stats.get("evaluated", 0) or 0)
    adjusted = int(stats.get("applied", 0) or 0)
    if evaluated <= 0 and adjusted <= 0:
        return "Pass — no cut-bias candidates were evaluated in this run."
    if adjusted <= evaluated:
        return "Pass — adjusted unique cards do not exceed evaluated unique cards."
    return "Review — adjusted unique cards exceed evaluated unique cards; inspect bias counters."


def _qa_cut_bias_activity_verdict(philosophy_context: dict[str, Any]) -> str:
    stats = philosophy_context.get("cut_bias_runtime_stats") or {}
    evaluated = int(stats.get("evaluated", 0) or 0)
    adjusted = int(stats.get("applied", 0) or 0)
    label = str(philosophy_context.get("label", "")).lower()
    key = str(philosophy_context.get("key", "")).lower()
    if evaluated <= 0:
        return "No eligible cut-bias candidates were evaluated."
    ratio = adjusted / evaluated
    if adjusted == 0:
        return "No cut-bias matches this run; acceptable for lenses requiring explicit pilot declarations or narrow evidence."

    # v0.6.6.5.2: thresholds are lens-aware. Balanced / Unknown should stay
    # quiet; specialized lenses may be more active when the deck provides real
    # evidence.
    if key == "balanced_unknown" or "balanced" in label:
        if ratio >= 0.50:
            return "Review — Balanced / Unknown is still too active; it should stay mostly neutral."
        if ratio >= 0.25:
            return "Watch — Balanced / Unknown has visible activity; confirm it is limited to clear plan/off-plan evidence."
        return "Pass — Balanced / Unknown stayed appropriately conservative."

    if "pet card" in label:
        if ratio >= 0.25:
            return "Review — Pet Card is active; confirm declared pet-card evidence exists."
        return "Pass — Pet Card stayed conservative unless explicit pet-card evidence exists."

    if "power-level calibrator" in label:
        if ratio >= 0.90:
            return "Review — Power-Level Calibrator is very active; acceptable only if bracket-pressure evidence is high."
        if ratio >= 0.75:
            return "Watch — Power-Level Calibrator is active; verify examples are real table-fit or bracket-pressure concerns."
        return "Normal activity — table-fit bias is visible without adjusting nearly every card."

    if ratio >= 0.90:
        return "High activity — review for overbroad aliases before lock."
    if ratio >= 0.75:
        return "Moderate/high activity — acceptable if examples are real plan support; review manually."
    return "Normal activity — bias is visible without adjusting nearly every card."


def _qa_pet_card_verdict(philosophy_context: dict[str, Any]) -> str:
    label = str(philosophy_context.get("label", "")).lower()
    if "pet card" not in label:
        return "Not applicable."
    stats = philosophy_context.get("cut_bias_runtime_stats") or {}
    adjusted = int(stats.get("applied", 0) or 0)
    if adjusted == 0:
        return "Pass — no declared pet card evidence, so the lens did not randomly protect cards."
    return "Review — Pet Card bias adjusted cards; confirm a declared pet card or explicit pilot protection exists."


def _qa_commander_exploiter_verdict(philosophy_context: dict[str, Any]) -> str:
    label = str(philosophy_context.get("label", "")).lower()
    if "commander exploiter" not in label:
        return "Not applicable."
    stats = philosophy_context.get("cut_bias_runtime_stats") or {}
    evaluated = int(stats.get("evaluated", 0) or 0)
    adjusted = int(stats.get("applied", 0) or 0)
    if evaluated <= 0:
        return "No eligible candidates evaluated."
    ratio = adjusted / evaluated
    if ratio >= 0.90:
        return "Review — very high Commander Exploiter activity; ensure generic support is not over-flagged."
    if ratio >= 0.75:
        return "Watch — high Commander Exploiter activity; acceptable only when examples clearly touch commander text."
    return "Pass — Commander Exploiter activity is not overbroad by count."


def _qa_replacement_metric(context: dict[str, Any], primary: str, fallback: str | None = None) -> int:
    summary = context.get("collection_candidates")
    if not summary:
        return 0
    value = getattr(summary, primary, None)
    if value is None and fallback:
        value = getattr(summary, fallback, 0)
    return int(value or 0)


def _qa_replacement_visibility_verdict(context: dict[str, Any]) -> str:
    summary = context.get("collection_candidates")
    if not summary or not getattr(summary, "active", False):
        return "Not applicable — collection candidate matching was not active."
    evaluated = _qa_replacement_metric(context, "replacement_bias_candidates_evaluated")
    nudged = _qa_replacement_metric(context, "replacement_bias_candidates_nudged", "replacement_bias_adjusted_cards")
    no_match = _qa_replacement_metric(context, "replacement_bias_candidates_no_match")
    no_evidence = _qa_replacement_metric(context, "replacement_bias_candidates_no_deck_evidence")
    if evaluated <= 0:
        return "Review — replacement bias active but no candidate evaluation count was recorded."
    if nudged + no_match + no_evidence <= 0:
        return "Review — replacement candidates were evaluated but no visibility buckets were recorded."
    return "Pass — replacement-bias counters are visible and bucketed."


def _companion_legality_result_text(legality: Any) -> str:
    checked = bool(getattr(legality, "companion_legality_checked", False))
    if not checked:
        return "Not checked"
    legal = getattr(legality, "companion_legality_legal", None)
    violations = list(getattr(legality, "companion_legality_violations", []) or [])
    manual_reviews = list(getattr(legality, "manual_review_companion_cards", []) or [])
    if legal is True:
        return "Pass"
    if violations:
        return "Violation found by automated companion check"
    if manual_reviews:
        return "Manual review required — automated restriction check is incomplete for this companion"
    return "Needs review — automated companion result was inconclusive"


def build_legality_debug_section(context: dict[str, Any]) -> str:
    parsed = context["parsed_deck"]
    command_zone = context["command_zone"]
    legality = context["legality"]
    lines = [
        "# Debug — Legality",
        "",
        f"Deck file: {parsed.deck_file}",
        f"Deck card count: {parsed.deck_card_count}",
        f"Commander(s): {', '.join(command_zone.commander_names) if command_zone.commander_names else 'Unknown'}",
        f"Command-zone rule: {command_zone.command_zone_rule_detected}",
        f"Commander color identity: {command_zone.commander_color_identity_text}",
        f"Deck size legal: {legality.deck_size_legal}",
        f"Companion(s): {', '.join(getattr(command_zone, 'companion_names', []) or []) if getattr(command_zone, 'companion_names', []) else 'None'}",
        f"Possible reference companion(s): {', '.join(getattr(command_zone, 'possible_reference_companion_names', []) or []) if getattr(command_zone, 'possible_reference_companion_names', []) else 'None'}",
        f"Companion legality checked: {getattr(legality, 'companion_legality_checked', False)}",
        f"Companion legality legal: {getattr(legality, 'companion_legality_legal', None)}",
        f"Companion legality result: {_companion_legality_result_text(legality)}",
        f"Companion legality violations found by automation: {len(getattr(legality, 'companion_legality_violations', []) or [])}",
        f"Manual companion reviews: {len(getattr(legality, 'manual_review_companion_cards', []) or [])}",
        "",
        "## Cards not found",
        *_bullet_list(legality.cards_not_found),
        "",
        "## Color identity violations",
    ]
    if legality.color_identity_violations:
        for item in legality.color_identity_violations:
            lines.append(f"- {item.get('card_name')}: card {item.get('card_color_identity')} vs commander {item.get('commander_color_identity')}")
    else:
        lines.append("- None")
    lines.extend(["", "## Illegal duplicates"])
    if legality.illegal_duplicate_cards:
        for item in legality.illegal_duplicate_cards:
            lines.append(f"- {item.get('card_name')}: {item.get('quantity')} copies")
    else:
        lines.append("- None")

    lines.extend(["", "## Companion legality notes"])
    companion_notes = list(getattr(legality, "companion_legality_notes", []) or [])
    lines.extend(_bullet_list(companion_notes))

    lines.extend(["", "## Companion recommendation filters"])
    filter_notes = list(getattr(legality, "companion_replacement_filter_notes", []) or [])
    lines.extend(_bullet_list(filter_notes))

    lines.extend(["", "## Companion legality violations"])
    violations = list(getattr(legality, "companion_legality_violations", []) or [])
    if violations:
        for item in violations:
            lines.append(f"- {item.get('card_name')} x{item.get('quantity', 1)}: {item.get('reason')}")
    else:
        lines.append("- None")

    lines.extend(["", "## Manual companion reviews"])
    manual_reviews = list(getattr(legality, "manual_review_companion_cards", []) or [])
    if manual_reviews:
        for item in manual_reviews:
            lines.append(f"- {item.get('card_name')}: {item.get('reason')}")
    else:
        lines.append("- None")

    return "\n".join(lines)


def build_strategy_debug_section(context: dict[str, Any]) -> str:
    role_summary = context["role_summary"]
    strategy = context["strategy_summary"]
    plan_fit = context["plan_fit_summary"]
    lines = [
        "# Debug — Strategy",
        "",
        f"Primary strategy: {strategy.primary_strategy}",
        f"Secondary strategy: {strategy.secondary_strategy}",
        f"Confidence: {strategy.confidence}",
        "",
        "## Top role counts",
    ]
    for tag, count in role_summary.role_counts.most_common(25):
        lines.append(f"- {tag}: {count}")
    lines.extend(["", "## Strategy candidates"])
    for candidate in strategy.candidates[:20]:
        lines.append(f"- {candidate.name}: score {candidate.score}; layer {candidate.layer}; gate {candidate.gate_passed}; {candidate.gate_reason}")
    lines.extend(["", "## Strong synergy examples"])
    for entry in plan_fit.strong_synergy_cards[:20]:
        lines.append(f"- {entry.card_name}: {'; '.join(entry.reasons)}")
    lines.extend(["", "## Possible off-plan examples"])
    for entry in plan_fit.possible_off_plan_cards[:20]:
        lines.append(f"- {entry.card_name}: {'; '.join(entry.reasons)}")
    return "\n".join(lines)


def build_bracket_debug_section(context: dict[str, Any]) -> str:
    bracket = context["bracket_summary"]
    lines = [
        "# Debug — Bracket Pressure",
        "",
        f"Estimated pressure: {bracket.estimated_bracket}",
        f"Pressure level: {bracket.pressure_level}",
        "",
        "## Notes",
        *_bullet_list(bracket.notes),
        "",
        "## Pressure cards",
    ]
    if bracket.pressure_cards:
        for entry in bracket.pressure_cards:
            lines.append(f"- {entry.card_name} x{entry.quantity}: {entry.pressure_type} — {entry.reason}")
    else:
        lines.append("- None")
    return "\n".join(lines)


def build_cut_pressure_debug_section(context: dict[str, Any]) -> str:
    cut_pressure = context["cut_pressure"]
    possible = context["possible_cuts"]
    lines = [
        "# Debug — Cut Pressure",
        "",
        f"Status: {cut_pressure.status}",
        f"Current deck size: {cut_pressure.deck_card_count}",
        f"Required cuts: {cut_pressure.required_cuts}",
        f"Short cards: {cut_pressure.short_cards}",
        f"Optional cut target: {cut_pressure.optional_cut_target}",
        f"Cut mode: {cut_pressure.cut_mode}",
        "",
        "## Notes",
        *_bullet_list(cut_pressure.notes + possible.notes),
        "",
        "## Required candidates",
    ]
    for entry in possible.required_cut_candidates:
        lines.append(f"- {entry.card_name}: {entry.cut_type}; confidence {entry.cut_confidence}; score {entry.score}; {'; '.join(entry.reasons)}")
    if not possible.required_cut_candidates:
        lines.append("- None")
    lines.extend(["", "## Optional candidates"])
    for entry in possible.optional_cut_candidates:
        lines.append(f"- {entry.card_name}: {entry.cut_type}; confidence {entry.cut_confidence}; score {entry.score}; {'; '.join(entry.reasons)}")
    if not possible.optional_cut_candidates:
        lines.append("- None")
    return "\n".join(lines)


def build_replacement_prompt_debug_section(context: dict[str, Any]) -> str:
    replacement = context["replacement_needs"]
    completion = context.get("deck_completion")
    legality = context.get("legality")
    lines = ["# Debug — Replacement / Completion", "", "## Priority categories"]
    lines.extend(_bullet_list(replacement.priority_categories))
    lines.extend(["", "## Replacement notes"])
    lines.extend(_bullet_list(replacement.notes))
    companion_filters = list(getattr(legality, "companion_replacement_filter_notes", []) or []) if legality else []
    lines.extend(["", "## Companion-aware recommendation filters"])
    lines.extend(_bullet_list(companion_filters))

    collection_summary = context.get("collection_summary")
    if collection_summary:
        lines.extend(["", "## Collection loader status"])
        lines.append(f"- Collection mode: {getattr(collection_summary, 'mode', 'none')}")
        lines.append(f"- Collection source mode: {getattr(collection_summary, 'source_mode', 'none')}")
        lines.append(f"- Collection folder: {getattr(collection_summary, 'collection_folder', None) or 'None'}")
        lines.append(f"- Selected collection files: {len(getattr(collection_summary, 'selected_files', []) or [])}")
        for file_path in list(getattr(collection_summary, 'selected_files', []) or [])[:5]:
            lines.append(f"  - {Path(file_path).name}")
        lines.append(f"- Collection loaded: {'Yes' if getattr(collection_summary, 'loaded', False) else 'No'}")
        lines.append(f"- Total owned cards loaded: {getattr(collection_summary, 'total_cards', 0)}")
        lines.append(f"- Unique owned card names: {getattr(collection_summary, 'unique_cards', 0)}")
        lines.append(f"- Cards not found in Scryfall: {len(getattr(collection_summary, 'not_found_cards', []) or [])}")
    if completion:
        lines.extend(["", "## Completion notes"])
        lines.append(f"- Cards needed: {completion.cards_needed}")
        lines.append(f"- Build-up mode: {completion.build_up_label}")
        lines.extend(_bullet_list(completion.notes))
    return "\n".join(lines)


def build_diagnostics_debug_section(context: dict[str, Any]) -> str:
    parsed = context["parsed_deck"]
    runtime_config = context["runtime_config"]
    original_runtime_config = context.get("original_runtime_config", runtime_config)
    philosophy_context = context.get("philosophy_context") or {}
    lines = [
        "# Debug — Diagnostics",
        "",
        f"Output mode: {runtime_config.output_mode}",
        f"Review direction: {runtime_config.review_direction}",
        f"Original review direction: {getattr(original_runtime_config, 'review_direction', runtime_config.review_direction)}",
        f"Auto-batch source: {'deck_size' if getattr(original_runtime_config, 'review_direction', '') == 'batch_auto' else 'not_applicable'}",
        f"Auto-batch detected deck size: {parsed.deck_card_count if getattr(original_runtime_config, 'review_direction', '') == 'batch_auto' else 'not_applicable'}",
        f"Prompt interaction mode: {runtime_config.prompt_interaction_mode}",
        f"Philosophy key: {getattr(runtime_config, 'philosophy_key', 'balanced_unknown')}",
        f"Guide preference: {getattr(runtime_config, 'guide_preference', 'either')}",
        f"Resolved philosophy lens: {philosophy_context.get('label', 'Balanced / Unknown')}",
        f"Resolved guide: {philosophy_context.get('guide_name') or 'No named guide selected'}",
        f"Build-up config: {runtime_config.build_up_config}",
        f"Cut-depth config: {runtime_config.cut_depth_config}",
        f"Auto-batch pool note: {runtime_config.cut_depth_config.get('auto_batch_pool_note', 'None')}",
        f"Collection mode: {getattr(runtime_config, 'collection_mode', 'none')}",
        f"Collection source mode: {getattr(runtime_config, 'collection_source_mode', 'none')}",
        f"Collection file/folder: {getattr(runtime_config, 'collection_file', '') or 'None'}",
        f"Selected collection files: {len(getattr(runtime_config, 'collection_files', ()) or ())}",
        "",
    ]
    if philosophy_context:
        lines.extend(render_philosophy_diagnostics_section(philosophy_context).splitlines())
        lines.extend([
            "",
            "## Philosophy Guidance Integration",
            "- v0.6.5.1 report guidance active: Yes",
            "- v0.6.5.3 subtype report summaries active: Yes",
            f"- Philosophy subtype summary active: {'Yes' if philosophy_context.get('subtype_summary_active') else 'No'}",
            f"- Report guidance summary available: {'Yes' if philosophy_context.get('report_guidance_summary') else 'No'}",
            f"- Protect / Question / Prefer fields available: {'Yes' if philosophy_context.get('protect_summary') and philosophy_context.get('question_summary') and philosophy_context.get('prefer_summary') else 'No'}",
            "- Scope: normal report guidance and diagnostics plus v0.6.6.1 bias foundation metadata",
            "- Cut scoring changed by philosophy: Yes — v0.6.6.3.1 light optional-cut bias and completed protected/watch fields are active",
            "- Replacement scoring changed by philosophy: Yes — v0.6.6.5 philosophy-bias QA / stress-test checkpoint is active",
            "- Strategy detection changed by philosophy: No",
            "- Collection candidate matching changed by philosophy: No",
            "- Current philosophy scoring phase: v0.6.6.6 v0.6.6 Lock / Bias Documentation",
            "- Next philosophy scoring phase: v0.6.7 Desktop UI Foundation / next roadmap phase",
            "",
            "## v0.6.6.1 Philosophy Bias Rules Foundation",
            "- v0.6.6.1 philosophy bias foundation active: Yes",
            f"- Bias profile available: {'Yes' if philosophy_context.get('philosophy_bias_foundation_active') else 'No'}",
            f"- Bias profile version: {philosophy_context.get('philosophy_bias_foundation_version', 'v0.6.6.2')}",
            "- v0.6.6.2.2 optional-cut bias cleanup active: Yes",
            f"- Selected lens bias strength: {philosophy_context.get('bias_strength', 'guidance')}",
            f"- Bias currently applied to cut scoring: {'Yes' if philosophy_context.get('cut_bias_scoring_active') or philosophy_context.get('bias_scoring_active') else 'No'}",
            f"- Bias currently applied to replacement scoring: {'Yes' if philosophy_context.get('replacement_bias_scoring_active') else 'No'}",
            f"- Protect-biased roles available: {'Yes' if philosophy_context.get('cut_bias_protect_roles') else 'No'}",
            f"- Review-biased roles available: {'Yes' if philosophy_context.get('cut_bias_review_roles') else 'No'}",
            f"- Replacement-biased roles available: {'Yes' if philosophy_context.get('replacement_bias_roles') else 'No'}",
            "- Foundation boundary: v0.6.6.6 locks small optional-cut nudges, completed protected/watch-card report fields, replacement-bias visibility, balanced-neutrality cleanup, and companion manual-review wording. It does not alter legality, required cuts, strategy detection, collection mode, color identity, companion restrictions, or quality gates.",
            f"- Protect-biased role examples: {', '.join((philosophy_context.get('cut_bias_protect_roles') or [])[:10]) if philosophy_context.get('cut_bias_protect_roles') else 'None'}",
            f"- Review-biased role examples: {', '.join((philosophy_context.get('cut_bias_review_roles') or [])[:10]) if philosophy_context.get('cut_bias_review_roles') else 'None'}",
            f"- Replacement-biased role examples: {', '.join((philosophy_context.get('replacement_bias_roles') or [])[:10]) if philosophy_context.get('replacement_bias_roles') else 'None'}",
            f"- Bias warning: {philosophy_context.get('bias_warning', 'v0.6.6.2 applies light optional-cut bias only.')}",
            "",
            "## v0.6.6.2.2 Philosophy Bias Counter / Infrastructure Suppression Hotfix",
            "- v0.6.6.2.2 optional-cut bias cleanup active: Yes",
            "- Bias applies to: optional cut scoring / replaceability review only",
            "- Bias does not apply to: legality, required cuts, color identity, banned cards, illegal duplicates, companion restrictions, strategy detection, collection candidate matching, or replacement scoring",
            "- Bias style: light nudge, not hard override",
            f"- Selected lens: {philosophy_context.get('label', 'Balanced / Unknown')}",
            f"- Bias strength: {philosophy_context.get('bias_strength', 'guidance')}",
            f"- Protect-biased roles checked: {'Yes' if philosophy_context.get('cut_bias_protect_roles') else 'No'}",
            f"- Review-biased roles checked: {'Yes' if philosophy_context.get('cut_bias_review_roles') else 'No'}",
            "- Report evidence: philosophy adjustments appear inside cut/review reasons when a card is nudged.",
            f"- Bias evaluated unique cards this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('evaluated', 0)}",
            f"- Bias-adjusted unique cards this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('applied', 0)}",
            f"- Total bias hits this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('total_bias_hits', 0)}",
            f"- Protect-side adjusted unique cards this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('protected_adjustments', 0)}",
            f"- Review-side adjusted unique cards this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('review_adjustments', 0)}",
            f"- Bias no-match unique cards this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('no_match', 0)}",
            f"- Mana-base infrastructure review notes suppressed: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('suppressed_infrastructure_review', 0)}",
            f"- Overbroad philosophy-bias matches suppressed: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('suppressed_overbroad_bias', 0)}",
            f"- Bias-applied examples: {', '.join((philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_applied_cards', [])[:8]) if (philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_applied_cards') else 'None'}",
            f"- Bias no-match examples: {', '.join((philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_no_match_cards', [])[:8]) if (philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_no_match_cards') else 'None'}",
            f"- Suppressed mana-base examples: {', '.join((philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_suppressed_infrastructure_review_cards', [])[:8]) if (philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_suppressed_infrastructure_review_cards') else 'None'}",
            f"- Suppressed overbroad-bias examples: {', '.join((philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_suppressed_overbroad_bias_cards', [])[:8]) if (philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_suppressed_overbroad_bias_cards') else 'None'}",
            "- Visibility note: adjusted unique cards should never exceed evaluated unique cards; total bias hits may be higher because one card can match multiple protect/review roles.",
            "- Mana-base suppression active: Yes — normal fixing lands should not receive Commander Exploiter generic-goodstuff review-pressure notes.",
            "- Trigger-amplifier cleanup active: Yes — Panharmonicon/Strionic Resonator-style cards can receive trigger/copy/ETB amplifier role tags when detected.",
            "- Safety rule: pilot-stated protected cards and required legality fixes still outrank philosophy bias.",
            "",
            "## v0.6.6.3.1 Protected Watch Language Field Completion Hotfix",
            "- v0.6.6.3.1 protected/watch language field completion active: Yes",
            "- Applies to: protected-from-cut entries, context-dependent keeps, and playtest/watch-card verdicts generated by the replaceability review",
            "- Purpose: make philosophy-adjusted keep decisions easier for the pilot or reviewing AI to understand",
            "- Expected protected/watch fields: Protected Label, Initial flag, Philosophy adjustment, Final verdict, Why this matters, Review instruction",
            f"- Protected/watch language entries this run: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('watch_language_entries', 0)}",
            f"- Protected/watch language examples: {', '.join((philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_watch_language_cards', [])[:8]) if (philosophy_context.get('cut_bias_runtime_stats') or {}).get('example_watch_language_cards') else 'None'}",
            "- Review instruction behavior: protected cards should say how to evaluate them, not merely say they are not cuts",
            "- Watch-card boundary: philosophy can lower optional cut pressure, but pilot intent and playtest results still decide the final keep/cut",
            "- Required legality boundary: required legality fixes still outrank protected/watch language",
            "",
            "## v0.6.6.4.2 Replacement Bias Language and Alias Precision Cleanup — carried into v0.6.6.5",
            "- v0.6.6.4.2 replacement bias language/alias cleanup active: Yes",
            "- v0.6.6.6 lock status: replacement-bias counters remain active, overbroad cut-bias aliases are tightened, and QA documentation is recorded.",
            "- Applies to: collection candidate presentation, light ordering nudges, debug counters, and role-alias matching",
            "- Does not apply to: legality, color identity, companion filters, required cuts, collection mode, or quality-gate overrides",
            f"- Selected replacement lens: {philosophy_context.get('label', 'Balanced / Unknown')}",
            f"- Replacement-biased roles available: {', '.join((philosophy_context.get('replacement_bias_roles') or [])[:8]) if philosophy_context.get('replacement_bias_roles') else 'None'}",
            "- Role-alias precision cleanup active: Yes — human-facing philosophy terms map to concrete card roles, and Big Creature/Stompy aliases avoid treating small typal bodies as large central creatures.",
            "- Safety rule: philosophy replacement fit is never an automatic swap recommendation.",
            "- Collection-only boundary: if the selected collection has no real fit, the report should say so instead of forcing a weak recommendation.",
            "",
            "## v0.6.6.5.2 Balanced Neutrality and Companion Review Wording Cleanup — locked into v0.6.6.6",
            "- v0.6.6.5.2 balanced-neutrality and companion-review cleanup active: Yes — locked into v0.6.6.6",
            "- Purpose: verify that philosophy bias helps explanation without becoming a hard override, while companion reports distinguish manual review from automated violations. v0.6.6.6 records this as the locked philosophy-bias behavior.",
            f"- Lens under QA: {philosophy_context.get('label', 'Balanced / Unknown')}",
            f"- Guide under QA: {philosophy_context.get('guide_name') or 'No named guide selected'}",
            f"- Primary question present: {'Yes' if (philosophy_context.get('primary_question') or philosophy_context.get('core_question')) else 'No'}",
            f"- Bias strength under QA: {philosophy_context.get('bias_strength', 'guidance')}",
            f"- Cut-bias scoring active: {'Yes' if philosophy_context.get('cut_bias_scoring_active') or philosophy_context.get('bias_scoring_active') else 'No'}",
            f"- Replacement-bias scoring active: {'Yes' if philosophy_context.get('replacement_bias_scoring_active') else 'No'}",
            f"- Cut-bias evaluated cards: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('evaluated', 0)}",
            f"- Cut-bias adjusted cards: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('applied', 0)}",
            f"- Cut-bias adjustment ratio: {_format_qa_ratio((philosophy_context.get('cut_bias_runtime_stats') or {}).get('applied', 0), (philosophy_context.get('cut_bias_runtime_stats') or {}).get('evaluated', 0))}",
            f"- Cut-bias counter sanity: {_qa_counter_sanity(philosophy_context)}",
            f"- Cut-bias activity verdict: {_qa_cut_bias_activity_verdict(philosophy_context)}",
            f"- Overbroad-bias matches suppressed: {(philosophy_context.get('cut_bias_runtime_stats') or {}).get('suppressed_overbroad_bias', 0)}",
            f"- Pet Card declaration check: {_qa_pet_card_verdict(philosophy_context)}",
            f"- Commander Exploiter overactivity check: {_qa_commander_exploiter_verdict(philosophy_context)}",
            f"- Replacement-bias candidates evaluated: {_qa_replacement_metric(context, 'replacement_bias_candidates_evaluated')}",
            f"- Replacement-bias candidates nudged: {_qa_replacement_metric(context, 'replacement_bias_candidates_nudged', 'replacement_bias_adjusted_cards')}",
            f"- Replacement-bias no-match candidates: {_qa_replacement_metric(context, 'replacement_bias_candidates_no_match')}",
            f"- Replacement-bias evidence-gap candidates: {_qa_replacement_metric(context, 'replacement_bias_candidates_no_deck_evidence')}",
            f"- Replacement-bias visibility verdict: {_qa_replacement_visibility_verdict(context)}",
            "- Required legality boundary: philosophy bias must not override required cuts, illegal duplicates, banned cards, color identity, or companion restrictions.",
            "- Collection honesty boundary: philosophy bias must not force collection-only recommendations when no owned card is a real fit.",
            "- QA test targets: Balanced / Unknown, Pet Card without declared pet card, Engine Builder, Commander Exploiter, Power-Level Calibrator, Big Moment or Big Creature / Stompy.",
            "- QA pass condition: readable explanations, visible counters, no forced bad recommendations, no legality override, and no uncontrolled overactive bias.",
            "",
            "## v0.6.6.6 v0.6.6 Lock / Bias Documentation",
            "- v0.6.6.6 lock checkpoint active: Yes",
            "- Purpose: document and lock the v0.6.6 philosophy-bias milestone after QA cleanup.",
            "- Locked behavior: philosophy can lightly nudge optional cut pressure, protected/watch-card explanations, and collection-candidate presentation/order.",
            "- Locked boundary: philosophy cannot override legality, required cuts, deck size, color identity, banned cards, illegal duplicates, companion restrictions, collection mode, quality gates, or explicit pilot intent.",
            "- Balanced / Unknown lock rule: stay mostly neutral; apply visible bias only to clear off-plan or explicit user-intent-conflict cases.",
            "- Pet Card lock rule: do not protect cards merely because Pet Card is selected; declared pet-card evidence or pilot protection is required.",
            "- Commander Exploiter lock rule: protect commander-specific support only when card roles or plan evidence connect to commander text.",
            "- Replacement-bias lock rule: owned-card philosophy fit is a presentation/order nudge only, never an automatic swap or strong-candidate override.",
            "- Companion lock rule: unsupported companion restrictions must report manual review required instead of implying an automated violation.",
            "- Recommended locked test coverage: Balanced / Unknown, Pet Card, Commander Exploiter, Engine Builder, Power-Level Calibrator, Competitive Closer, Big Moment / Big Creature.",
            "- v0.6.6 milestone verdict: Ready to treat as the current stable philosophy-bias checkpoint if local tests match expected diagnostics.",
            "",
            "## v0.6.5.5 Philosophy Batch QA / Stress-Test Summary",
            "- v0.6.5.5 batch QA checkpoint active: Yes",
            "- Purpose: confirm philosophy guidance remains stable across multiple decks, lenses, guides, prompt modes, collection modes, and batch runs before locking v0.6.5.",
            f"- Selected lens under test: {philosophy_context.get('label', 'Balanced / Unknown')}",
            f"- Selected guide under test: {philosophy_context.get('guide_name') or 'No named guide selected'}",
            f"- Guide/persona role: {philosophy_context.get('guide_role') or 'No named guide role'}",
            f"- Primary lens question present: {'Yes' if (philosophy_context.get('primary_question') or philosophy_context.get('core_question')) else 'No'}",
            f"- Short lens summary present: {'Yes' if philosophy_context.get('short_lens_summary') else 'No'}",
            f"- Report guidance summary present: {'Yes' if philosophy_context.get('report_guidance_summary') else 'No'}",
            f"- Protect summary present: {'Yes' if philosophy_context.get('protect_summary') else 'No'}",
            f"- Question/review summary present: {'Yes' if philosophy_context.get('question_summary') else 'No'}",
            f"- Prefer/replacement summary present: {'Yes' if philosophy_context.get('prefer_summary') else 'No'}",
            "- Expected prompt behavior: ask for deck report first, introduce the guide once, ask one section at a time, use clean `1 = choice` options, summarize each completed section, and ask only for missing items on partial section answers.",
            "- Expected report behavior: show lens summary, how to use the lens, Protect / Question / Prefer, and boundary language.",
            "- Expected scoring behavior: guidance-only; no cut-score, replacement-score, strategy, legality, collection, or deck-size changes in v0.6.5.x.",
            "- Batch QA test targets: Balanced / Unknown, Theme / Vibe, Commander Exploiter, Combo Builder or Engine Builder, Power-Level Calibrator or Curve and Mana Discipline, and one Timmy / Tammy spectacle lens.",
            "- Pass condition: prompts and reports remain readable, mechanical boundaries remain intact, and the selected lens improves explanation quality without making unsupported mechanical decisions.",
            "- Next checkpoint after passing batch QA: v0.6.5.6 v0.6.5 Lock / First Trusted Preview Candidate.",
            "",
        ])

    collection_summary = context.get("collection_summary")
    if collection_summary:
        selected_files = list(getattr(collection_summary, 'selected_files', []) or [])
        lines.extend([
            "## Collection Loader Diagnostics",
            f"- Collection mode: {getattr(collection_summary, 'mode', 'none')}",
            f"- Collection source mode: {getattr(collection_summary, 'source_mode', 'none')}",
            f"- Collection folder: {getattr(collection_summary, 'collection_folder', None) or 'None'}",
            f"- Selected collection files: {len(selected_files)}",
        ])
        for file_path in selected_files[:12]:
            lines.append(f"  - {Path(file_path).name}")
        if len(selected_files) > 12:
            lines.append(f"  - ...and {len(selected_files) - 12} more")
        lines.extend([
            f"- At least one collection file exists: {'Yes' if getattr(collection_summary, 'file_exists', False) else 'No'}",
            f"- Loaded: {'Yes' if getattr(collection_summary, 'loaded', False) else 'No'}",
            f"- Total owned cards loaded: {getattr(collection_summary, 'total_cards', 0)}",
            f"- Unique owned card names: {getattr(collection_summary, 'unique_cards', 0)}",
            f"- Collection entries matched to Scryfall: {getattr(collection_summary, 'found_cards', 0)}",
            f"- Collection cards not found in Scryfall: {len(getattr(collection_summary, 'not_found_cards', []) or [])}",
            "- Candidate matching active: Yes — v0.6.4.3 matches loaded collection cards to current deck needs.",
            "",
            "### Collection Scryfall Resolution",
            f"- Exact-name matches: {getattr(collection_summary, 'exact_name_matches', 0)}",
            f"- Normalized-name matches: {getattr(collection_summary, 'normalized_name_matches', 0)}",
            f"- Set-code / collector-number matches: {getattr(collection_summary, 'set_collector_matches', 0)}",
            f"- Printed/alternate-name matches: {getattr(collection_summary, 'printed_or_alternate_name_matches', 0)}",
            f"- Unresolved entries: {getattr(collection_summary, 'unresolved_entries', 0)}",
        ])
        resolved_examples = list(getattr(collection_summary, 'resolved_name_examples', []) or [])
        not_found = list(getattr(collection_summary, 'not_found_cards', []) or [])
        warnings = list(getattr(collection_summary, 'parse_warnings', []) or [])
        if resolved_examples:
            lines.append("- Resolved alternate/export-name examples: " + " | ".join(resolved_examples[:8]))
        if not_found:
            lines.append("- Not-found examples: " + ", ".join(not_found[:12]))
            lines.append("- Not-found note: These entries were not fuzzy-corrected. Fix scanner/export spelling or confirm that the card exists in the local Scryfall data.")
        if warnings:
            lines.append("- Parse warning examples: " + " | ".join(warnings[:5]))
        lines.append("")

    collection_candidates = context.get("collection_candidates")
    if collection_candidates:
        lines.extend([
            "## Collection Candidate Matching Diagnostics",
            f"- Candidate matching active: {'Yes' if getattr(collection_candidates, 'candidate_matching_active', False) else 'No'}",
            f"- Collection mode: {getattr(collection_candidates, 'mode', 'none')}",
            f"- Strong owned candidates: {len(getattr(collection_candidates, 'strong_candidates', []) or [])}",
            f"- Possible owned candidates: {len(getattr(collection_candidates, 'possible_candidates', []) or [])}",
            f"- Shakeup-only candidates: {len(getattr(collection_candidates, 'shakeup_candidates', []) or [])}",
            f"- Rejected / filtered owned cards tracked: {len(getattr(collection_candidates, 'rejected_candidates', []) or [])}",
            "- Quality gate active: Yes — broad role overlap alone is not enough for Strong candidates.",
            "- Semantic gate active: Yes — support-only matches are not displayed as matched deck needs.",
            "- Role mapping hardening active: Yes — evasion/trample, board wipe, token, and combat categories use exact semantic gates.",
            "- Strong promotion gate active: Yes — standalone beaters, generic colorless bodies, and self-protection cards are usually capped at Possible.",
            "- v0.6.4.4 report/prompt integration active: Yes — candidates are review candidates, not automatic swaps.",
            "- Artifact-context cap active: Yes — artifact-context-dependent cards require artifact deck support before Strong.",
            "- Role-by-role gap tracking active: Yes — Possible and Shakeup candidates do not close strong-fit gaps.",
            "- v0.6.6.4.2 replacement bias language/alias cleanup active: " + ("Yes" if getattr(collection_candidates, 'replacement_bias_active', False) else "No"),
            f"- Replacement bias lens: {getattr(collection_candidates, 'replacement_bias_lens', 'Balanced / Unknown')}",
            f"- Replacement-biased roles checked: {', '.join(list(getattr(collection_candidates, 'replacement_bias_roles_checked', []) or [])[:8]) if getattr(collection_candidates, 'replacement_bias_roles_checked', []) else 'None'}",
            f"- Replacement candidates evaluated for bias: {getattr(collection_candidates, 'replacement_bias_candidates_evaluated', 0)}",
            f"- Replacement-biased candidates nudged: {getattr(collection_candidates, 'replacement_bias_candidates_nudged', getattr(collection_candidates, 'replacement_bias_adjusted_cards', 0))}",
            f"- Replacement candidates not nudged: {getattr(collection_candidates, 'replacement_bias_candidates_not_nudged', 0)}",
            f"- Replacement candidates with no bias-role match: {getattr(collection_candidates, 'replacement_bias_candidates_no_match', 0)}",
            f"- Replacement candidates with bias role but no deck-fit evidence: {getattr(collection_candidates, 'replacement_bias_candidates_no_deck_evidence', 0)}",
            f"- Replacement bias strong/possible/shakeup nudges: {getattr(collection_candidates, 'replacement_bias_strong_adjusted_cards', 0)}/{getattr(collection_candidates, 'replacement_bias_possible_adjusted_cards', 0)}/{getattr(collection_candidates, 'replacement_bias_shakeup_adjusted_cards', 0)}",
            f"- Strong candidates considered: {getattr(collection_candidates, 'strong_candidates_considered', 0)}",
            f"- Strong candidates accepted: {getattr(collection_candidates, 'strong_candidates_accepted', 0)}",
            f"- Downgraded to Possible: {getattr(collection_candidates, 'downgraded_to_possible', 0)}",
            f"- Downgraded to Shakeup: {getattr(collection_candidates, 'downgraded_to_shakeup', 0)}",
        ])
        no_fit = list(getattr(collection_candidates, 'no_strong_fit_categories', []) or [])
        notes = list(getattr(collection_candidates, 'notes', []) or [])
        quality_notes = list(getattr(collection_candidates, 'quality_gate_notes', []) or [])
        strong = list(getattr(collection_candidates, 'strong_candidates', []) or [])
        possible = list(getattr(collection_candidates, 'possible_candidates', []) or [])
        shakeup = list(getattr(collection_candidates, 'shakeup_candidates', []) or [])
        category_counts = list(getattr(collection_candidates, 'category_strong_fit_counts', []) or [])
        if category_counts:
            lines.append("- Strong-fit coverage by category: " + ", ".join(f"{cat}={count}" for cat, count in category_counts[:12]))
        if no_fit:
            lines.append("- Needs with no strong owned fit: " + ", ".join(no_fit[:12]))
        if notes:
            lines.append("- Candidate notes: " + " | ".join(notes[:4]))
        if quality_notes:
            lines.append("- Quality gate notes: " + " | ".join(quality_notes[:4]))
        downgrade_counts = list(getattr(collection_candidates, 'downgrade_reason_counts', []) or [])
        if downgrade_counts:
            lines.append("- Downgrade reasons: " + ", ".join(f"{reason}={count}" for reason, count in downgrade_counts[:8]))
        if strong:
            lines.append("- Strong owned examples: " + ", ".join(candidate.card_name for candidate in strong[:8]))
        if possible:
            lines.append("- Possible owned examples: " + ", ".join(candidate.card_name for candidate in possible[:8]))
        if shakeup:
            lines.append("- Shakeup examples: " + ", ".join(candidate.card_name for candidate in shakeup[:8]))
        rb_examples = list(getattr(collection_candidates, 'replacement_bias_examples', []) or [])
        rb_no_match = list(getattr(collection_candidates, 'replacement_bias_no_match_examples', []) or [])
        rb_no_evidence = list(getattr(collection_candidates, 'replacement_bias_no_evidence_examples', []) or [])
        if rb_examples:
            lines.append("- Replacement bias examples: " + ", ".join(rb_examples[:8]))
        if rb_no_match:
            lines.append("- Replacement bias no-match examples: " + ", ".join(rb_no_match[:8]))
        if rb_no_evidence:
            lines.append("- Replacement bias matched but lacked deck-fit evidence examples: " + ", ".join(rb_no_evidence[:8]))
        lines.append("")

    cards_by_section = getattr(parsed, "cards_by_section", {}) or {}
    reference_by_section = getattr(parsed, "reference_cards_by_section", {}) or {}
    card_roles = getattr(context.get("role_summary"), "card_roles", []) if context.get("role_summary") else []
    possible_companions = _possible_companion_names_from_reference(context)
    lines.extend([
        "## AI Handoff Export Checks",
        "- Full decklist expected in normal report: Yes",
        "- Annotated card role notes expected in normal report: Yes",
        "- Companion verification warning expected when reference companion is detected: Yes",
        f"- Main deck card count available to report: {parsed.deck_card_count}",
        f"- Unique main deck cards available to report: {len(parsed.unique_cards)}",
        f"- Sectioned main-deck groups available to report: {len(cards_by_section)}",
        f"- Annotated role entries available to report: {len(card_roles)}",
        f"- Reference/non-mainboard cards available to report: {parsed.reference_card_count}",
        f"- Reference/non-mainboard section groups available to report: {len(reference_by_section)}",
        f"- Possible companion detected in reference/non-mainboard cards: {'Yes' if possible_companions else 'No'}",
        f"- Possible companion names: {', '.join(possible_companions) if possible_companions else 'None'}",
        f"- Confirmed companion names: {', '.join(getattr(context.get('command_zone'), 'companion_names', []) or []) if getattr(context.get('command_zone'), 'companion_names', []) else 'None'}",
        f"- Companion legality checked: {'Yes' if getattr(context.get('legality'), 'companion_legality_checked', False) else 'No'}",
        f"- Companion legality violations: {len(getattr(context.get('legality'), 'companion_legality_violations', []) or [])}",
        f"- Manual companion reviews: {len(getattr(context.get('legality'), 'manual_review_companion_cards', []) or [])}",
    ])
    companion_debug_names = list(dict.fromkeys(possible_companions + list(getattr(context.get('command_zone'), 'companion_names', []) or [])))
    if companion_debug_names:
        lines.extend(["", "## Companion Intake Diagnostics"])
        for name in companion_debug_names:
            lines.append(f"### {name}")
            lines.append(f"- Restriction summary: {get_companion_restriction_summary(name)}")
            lines.append(f"- Recommendation filter: {get_companion_replacement_filter_note(name)}")
            lines.append(f"- Banned/manual warning: {get_companion_banned_note(name) if companion_is_banned_as_companion(name) else 'None'}")
    lines.extend([
        "",
        "## Parser hygiene",
        f"- Ignored/unparsed lines: {len(parsed.ignored_lines)}",
        f"- Reference/non-mainboard cards ignored: {parsed.reference_card_count}",
    ])
    if parsed.ignored_lines:
        lines.extend(["", "## Ignored lines"])
        lines.extend(_bullet_list(parsed.ignored_lines[:30]))
    return "\n".join(lines)


def write_debug_sections(deck_folder: Path, deck_name: str, context: dict[str, Any]) -> DebugSectionPaths:
    builders = [
        ("legality", build_legality_debug_section),
        ("strategy", build_strategy_debug_section),
        ("bracket", build_bracket_debug_section),
        ("cut_pressure", build_cut_pressure_debug_section),
        ("replacement_prompt", build_replacement_prompt_debug_section),
        ("diagnostics", build_diagnostics_debug_section),
    ]
    paths: dict[str, Path] = {}
    for key, builder in builders:
        path = get_unique_output_path(deck_folder, f"{deck_name}_{key}_debug", ".md")
        write_text_file(path, builder(context))
        paths[key] = path
    return DebugSectionPaths(
        legality=paths["legality"],
        strategy=paths["strategy"],
        bracket=paths["bracket"],
        cut_pressure=paths["cut_pressure"],
        replacement_prompt=paths["replacement_prompt"],
        diagnostics=paths["diagnostics"],
    )
