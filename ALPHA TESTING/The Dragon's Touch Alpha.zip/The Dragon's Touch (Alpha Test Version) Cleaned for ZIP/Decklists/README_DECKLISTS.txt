Decklists Folder

This folder contains sample Commander decklists for alpha testing.

Included samples:

1. Miirym Duplicate Legality Test
   Tests illegal duplicate reporting with 2 copies of Life Finds a Way.

2. Phelia Bracket 2 Test
   Tests lower-power / bracket-sensitive review behavior.

3. Voja Build-Up Test
   Tests an incomplete deck that needs 3 more cards to become legal.

4. Inga & Esika Companion Test
   Tests companion or restriction handling.

5. Toggo / Keskit Partner Test
   Tests partner commander handling and landfall/artifact/sacrifice package recognition.

You can add your own Commander decklists here.

How to add a deck:
1. Export or copy your decklist as plain text.
2. Save it as a .txt file.
3. Place it in this Decklists folder.
4. Select it from The Dragon's Touch Deck Selection page.

The included samples were created from Archidekt text exports. You are welcome to try .txt exports from other deckbuilding sites.

If a decklist does not load correctly, please report which site it came from, whether it was copied/pasted or downloaded, and what happened.