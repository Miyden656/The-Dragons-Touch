"""Future/placeholder workspace page builders for The Dragon's Touch UI.

These builders keep placeholder and settings page layout out of the main window while
leaving behavior ownership on MainWindow. They do not run backend work or enable any
deferred features.
"""

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout

    from ui.constants import APP_PHASE, APP_VERSION, LOCKED_BACKEND_VERSION
    from ui.styles.theme import ADVENTURERS_MAP, DRAGON_FORGE
    from ui.widgets import add_shadow, ReportCard, SmallStat, TexturedPanel
except ImportError:  # Allows direct execution from inside the ui/ folder during local testing.
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout

    from constants import APP_PHASE, APP_VERSION, LOCKED_BACKEND_VERSION
    from styles.theme import ADVENTURERS_MAP, DRAGON_FORGE
    from widgets import add_shadow, ReportCard, SmallStat, TexturedPanel


def build_batch_reports_page(host):
    """Build the Batch / Aggregate placeholder page."""
    self = host
    page, layout = self.page_container("Batch / Aggregate Reports", "Future / Not Active Yet. This placeholder does not run batch analysis or create aggregate reports in v0.7 alpha.")
    body = TexturedPanel(self.theme, kind="iron", glow=False); add_shadow(body, blur=24, y=8)
    b_layout = QVBoxLayout(body); b_layout.setContentsMargins(22, 22, 22, 22); b_layout.setSpacing(16)
    top = QHBoxLayout()
    for label, value in [("Batch Files", "Not selected"), ("Deck Reports", "Aggregate later"), ("Debug Reports", "Aggregate later"), ("Prompt Reports", "Not required")]:
        top.addWidget(SmallStat(label, value, self.theme))
    b_layout.addLayout(top)
    aggregate_panel = ReportCard("Aggregate Output Plan", self.theme, badges=[("Future / Not Active Yet", "manual")])
    aggregate_panel.body.addWidget(self.make_text(
        "The locked backend already supports useful report outputs. This page will eventually open the combined deck-report and debug-report files so you do not have to enter each deck output folder manually.",
        paper=True
    ))
    b_layout.addWidget(aggregate_panel)
    workflow = TexturedPanel(self.theme, kind="iron_2", glow=True)
    w_layout = QVBoxLayout(workflow); w_layout.setContentsMargins(18, 16, 18, 16)
    w_title = QLabel("Batch / Aggregate Boundary"); w_title.setObjectName("sectionTitle"); w_layout.addWidget(w_title)
    w_layout.addWidget(self.make_text("This page is a visual foundation only. The future backend hook should call the existing batch workflow and then surface aggregate markdown/text outputs here."))
    b_layout.addWidget(workflow); b_layout.addStretch(1); layout.addWidget(body, stretch=1); return page


def build_settings_page(host):
    """Build the Settings / checkpoint page."""
    self = host
    page, layout = self.page_container(
        "Settings",
        "Theme options, alpha status, deferred scope, and checkpoint notes for the modular v0.7 build."
    )
    scroll, content = self.scroll_content()
    body = TexturedPanel(self.theme, kind="iron", glow=False)
    add_shadow(body, blur=24, y=8)
    b_layout = QVBoxLayout(body)
    b_layout.setContentsMargins(22, 22, 22, 22)
    b_layout.setSpacing(16)

    theme_card = ReportCard("Theme Options", self.theme, badges=[("Current", "primary")])
    row = QHBoxLayout()
    dark = QPushButton("Dragon Forge")
    dark.setObjectName("primaryButton" if self.theme()["name"] == "Dragon Forge" else "utilityButton")
    dark.clicked.connect(lambda: self.set_theme(DRAGON_FORGE))
    light = QPushButton("Adventurer's Map")
    light.setObjectName("primaryButton" if self.theme()["name"] == "Adventurer's Map" else "utilityButton")
    light.clicked.connect(lambda: self.set_theme(ADVENTURERS_MAP))
    self.settings_theme_buttons = [(dark, "Dragon Forge"), (light, "Adventurer's Map")]
    row.addWidget(dark)
    row.addWidget(light)
    row.addStretch(1)
    theme_card.body.addLayout(row)
    theme_card.body.addWidget(self.make_text(
        "Dragon Forge remains the locked default. Adventurer’s Map remains available as the lighter cartographer palette.",
        paper=True
    ))
    b_layout.addWidget(theme_card)

    prefs = ReportCard("UI Preferences Checkpoint", self.theme, badges=[("Future controls", "manual")])
    prefs_box = self.readonly_text_box(
        "UI Preferences Checkpoint\n"
        "- Report detail level -> Detailed\n"
        "- Export format -> Markdown\n"
        "- Save folder -> Outputs/\n"
        "- Report Viewer text -> approved default for the v0.6.7 lock\n"
        "- Future settings home -> font family, font size, readability presets, export behavior, and saved user defaults\n"
        "- Current boundary -> these values are documented here but not yet persistent editable settings",
        min_height=115,
        max_height=150,
    )
    prefs_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    prefs.body.addWidget(prefs_box)
    prefs.body.addWidget(self.default_note("Displayed as a checkpoint summary for now. Full editable preferences come after the v0.6.7 foundation lock."))
    b_layout.addWidget(prefs)

    checkpoint = ReportCard("v0.7 Modular Alpha Checkpoint", self.theme, badges=[("Modular checkpoint", "protected"), ("CLI source", "manual")])
    checkpoint_text = (
        "Modular Alpha Checkpoint\n"
        "- Deck Selection, Review Setup, Philosophy Lens, Collection Source, Run Analysis, and Report Viewer are connected into one guarded local workflow.\n"
        "- The UI is a guarded frontend for the existing CLI/backend workflow; it is not a second backend.\n"
        "- CLI/main.py remains the source of truth for legality, strategy, collection loading, cuts, replacements, and report generation.\n"
        "- Backend output folders are unique per run and preserve commander/deck-filename distinction.\n"
        "- Report Viewer loads generated markdown/text as plain readable text.\n"
        "- Deferred intentionally: deep markdown rendering, structured report parsing, batch/aggregate viewing, user-configurable report font settings, and Commander Spellbook/API combo tracking.\n"
        "- Commander Spellbook remains disabled and future opt-in only."
    )
    checkpoint_box = self.readonly_text_box(checkpoint_text, min_height=155, max_height=210)
    checkpoint_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    checkpoint.body.addWidget(checkpoint_box)
    b_layout.addWidget(checkpoint)

    qa_card = ReportCard("Alpha Tester Smoke Checklist", self.theme, badges=[("QA checkpoint", "manual"), ("No new scope", "protected")])
    qa_text = (
        "Alpha Tester Smoke Checklist\n"
        "Deck Selection\n"
        "- Choose a deck file and confirm preview loads without overlap.\n"
        "- Confirm single commander, partner/paired commanders, and companion preview status display correctly.\n"
        "- Confirm deck counts separate main deck, commander cards, total Commander deck estimate, and companion cards.\n\n"
        "Review Setup\n"
        "- Confirm Output Mode, Review Direction, Review Intensity / Build-Up Mode, Prompt Mode, Budget Note, and Bracket Intended auto-stage immediately.\n"
        "- Confirm Cut down shows Review Intensity and Build up shows Build-Up Mode.\n\n"
        "Philosophy Lens\n"
        "- Confirm top-level philosophy, optional subtype, and Guide Presentation auto-stage cleanly.\n"
        "- Confirm dropdowns remain readable in both themes.\n\n"
        "Collection Source\n"
        "- Confirm No collection, Prefer collection first, Collection only, and Collection shakeup stage correctly.\n"
        "- Confirm Entire collection folder and Select collection files handoff states are correct.\n\n"
        "Run Analysis\n"
        "- Confirm guarded run requires confirmation and uses selected deck handoff.\n"
        "- Confirm diagnostics remain available behind the detail selector.\n"
        "- Confirm Commander Spellbook/API calls remain disabled.\n\n"
        "Report Viewer\n"
        "- Confirm generated reports are detected, grouped, loaded as plain text, searchable, copyable, and openable.\n"
        "- Confirm latest backend-created unique output folder opens correctly.\n\n"
        "Settings / Themes\n"
        "- Confirm Dragon Forge and Adventurer’s Map remain readable and no flash popup returns.\n"
        "- Confirm Settings clearly documents the v0.6.7 lock and future boundaries."
    )
    qa_box = self.readonly_text_box(qa_text, min_height=235, max_height=310)
    qa_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    qa_card.body.addWidget(qa_box)
    qa_card.body.addWidget(self.default_note("Checklist only: this patch documents the lock criteria without adding new features."))
    b_layout.addWidget(qa_card)

    release_card = ReportCard("Modular Alpha Notes and Deferred Scope", self.theme, badges=[("Release notes", "primary"), ("v0.7 active", "manual")])
    release_text = (
        "v0.7 Modular Alpha Notes\n"
        "Locked in this checkpoint\n"
        "- Single-deck desktop UI foundation.\n"
        "- Guarded main.py execution with explicit confirmation.\n"
        "- Backend-created unique timestamped output folders with deck filename distinction.\n"
        "- Report detection and Report Viewer plain-text loading.\n"
        "- Deck preview support for commanders, commander pairs, and companion status.\n"
        "- Collection source staging and CLI handoff.\n"
        "- Settings/status page describing the current lock boundary.\n\n"
        "Deferred intentionally\n"
        "- Batch / Aggregate real workflow.\n"
        "- Commander Spellbook/API combo tracking.\n"
        "- Deep markdown rendering and structured report section parsing.\n"
        "- Settings persistence, saved UI sessions, and full readability preferences.\n"
        "- Replacement Candidate Engine and future automation layers.\n\n"
        "Roadmap clarification\n"
        "- v0.6.7 = Desktop UI Foundation Lock.\n"
        "- v0.6.8 = Prompt / Report Polish + Stable v0.6 Lock.\n"
        "- v0.7 = Desktop UI Alpha Foundation / Alpha Hardening.\n"
        "- v0.7 builds on this locked UI foundation; it is not a rebuild from scratch."
    )
    release_box = self.readonly_text_box(release_text, min_height=210, max_height=285)
    release_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    release_card.body.addWidget(release_box)
    release_card.body.addWidget(self.default_note("Conservative roadmap wording only: no completed checkpoints were renamed or moved."))
    b_layout.addWidget(release_card)

    regression_card = ReportCard("Stable v0.6 Regression Pass", self.theme, badges=[("v0.6.8.4 passed", "primary"), ("QA complete", "protected")])
    regression_text = (
        "Stable v0.6 Regression Pass\n"
        "Purpose\n"
        "- Confirm the locked v0.6.7 desktop foundation and v0.6.8 prompt/report polish still work together.\n"
        "- Treat this as a QA checkpoint, not a feature patch.\n\n"
        "Required test coverage\n"
        "- Cut-down deck: confirm required cuts, optional cuts, duplicate legality priority, and report loading.\n"
        "- Build-up deck: confirm cards-needed count, build-up mode, completion prompt, and report loading.\n"
        "- Companion deck: confirm companion preview/status and backend legality boundaries when available.\n"
        "- Partner commander deck: confirm command-zone preview and selected deck handoff.\n"
        "- Collection modes: confirm No collection and Collection only remain clear and honest.\n"
        "- Output modes: confirm Normal, Debug, and Both still write expected files.\n"
        "- Output folders: confirm unique timestamped folders preserve commander name and source deck filename.\n"
        "- Report Viewer: confirm latest reports are detected and load as plain text.\n"
        "- Guarded execution: confirm main.py runs only after explicit confirmation and captures stdout/stderr.\n"
        "- Commander Spellbook/API: confirm external combo calls remain disabled/future opt-in.\n\n"
        "Pass condition\n"
        "- No regressions in guarded run, report generation, output folder routing, UI staging, or plain-text report viewing.\n"
        "- This pass is complete. v0.6.8.5 formally locks stable v0.6."
    )
    regression_box = self.readonly_text_box(regression_text, min_height=230, max_height=315)
    regression_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    regression_card.body.addWidget(regression_box)
    regression_card.body.addWidget(self.default_note("QA checkpoint passed: no new features, backend logic changes, API work, or markdown parser work added."))
    b_layout.addWidget(regression_card)

    stable_lock_card = ReportCard("Stable v0.6 Lock", self.theme, badges=[("v0.6.8.5", "primary"), ("Locked", "protected")])
    stable_lock_text = (
        "Stable v0.6 Lock\n"
        "Final lock status\n"
        "- v0.6 is now locked as a stable local Commander deck-review workflow.\n"
        "- v0.6.7 locked the Desktop UI Foundation.\n"
        "- v0.6.8 polished prompt wording, report wording, user-facing boundaries, and final regression coverage.\n"
        "- Guarded main.py execution remains the source-of-truth bridge between the UI and backend.\n"
        "- Backend-created unique timestamped output folders remain locked.\n"
        "- Report Viewer remains plain-text reading of generated reports.\n"
        "- Commander Spellbook/API calls remain disabled and future opt-in only.\n"
        "- Batch / Aggregate remains a placeholder/future workspace.\n\n"
        "Next roadmap step\n"
        "- v0.7 = Desktop UI Alpha Foundation / Alpha Hardening.\n"
        "- v0.7 builds on this locked v0.6 foundation; it is not a rebuild from scratch.\n"
        "- Future work should focus on alpha usability, not new major systems unless intentionally scoped."
    )
    stable_lock_box = self.readonly_text_box(stable_lock_text, min_height=210, max_height=285)
    stable_lock_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    stable_lock_card.body.addWidget(stable_lock_box)
    stable_lock_card.body.addWidget(self.default_note("Stable v0.6 lock checkpoint: preserve this behavior unless a future roadmap patch intentionally changes it."))
    b_layout.addWidget(stable_lock_card)

    version = ReportCard("App Version", self.theme, badges=[("Stable v0.6", "protected")])
    version_text = (
        "The Dragon’s Touch PySide6 Workstation\n"
        f"Version -> {APP_VERSION}\n"
        f"Phase -> {APP_PHASE}\n"
        f"Locked backend -> {LOCKED_BACKEND_VERSION}\n"
        "Backend -> guarded bridge available through explicit confirmation\n"
        "Foundation status -> Stable v0.6 locked; v0.6.7 Desktop UI Foundation locked; v0.6.8 polish/regression complete\n"
        "Stable workflow -> Deck Selection -> Review Setup -> Philosophy Lens -> Collection Source -> Run Analysis -> backend-created unique output folder -> Report Viewer plain-text reading\n"
        "Output pattern -> Outputs/<CommanderName>_<DeckFileStem>_run_<YYYYMMDD_HHMMSS>/\n"
        "Boundary -> no hidden API calls; Commander Spellbook/API remains disabled; Report Viewer does not deep-parse markdown yet; required cuts, legality fixes, collection mode, and philosophy guidance remain clearly separated; v0.7 means alpha hardening of this existing UI, not a rebuild."
    )
    version_box = self.readonly_text_box(version_text, min_height=135, max_height=185)
    version_box.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    version.body.addWidget(version_box)
    b_layout.addWidget(version)

    content.addWidget(body)
    content.addStretch(1)
    layout.addWidget(scroll, stretch=1)
    return page
